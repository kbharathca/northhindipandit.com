export type Puja = {
  slug: string;
  title: string;
  shortTitle: string;
  image: string;
  tagline: string;
  navLabel: string;
  heroTitle: string;
  heroDescription: string;
  seoTitle: string;
  seoDescription: string;
  benefits: string[];
  idealFor: string[];
  includes: string[];
  process: string[];
  faqs: { question: string; answer: string }[];
};

export const phoneNumber = '6206471543';
export const whatsappNumber = '6206471543';

export const getWhatsAppLink = (service: string) =>
  `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
    `Namaste, I want to book ${service} in Bangalore.\n\nName:\nLocation:\nPreferred Date:\nAdditional Details:`
  )}`;

export const pujas: Puja[] = [
  {
    slug: 'griha-pravesh-puja-bangalore',
    title: 'Griha Pravesh Puja in Bangalore',
    shortTitle: 'Griha Pravesh Puja',
    image: '/images/griha-pravesh-puja-all-puja.webp',
    tagline: 'A sacred housewarming puja for peace, prosperity, and auspicious beginnings.',
    navLabel: 'Griha Pravesh',
    heroTitle: 'Book Griha Pravesh Puja in Bangalore with Experienced North Hindi Pandit',
    heroDescription:
      'Welcome your family into the new home with shubh muhurat guidance, Vedic mantras, kalash sthapana, vastu shanti rituals, and complete puja samagri support across Bangalore.',
    seoTitle: 'Griha Pravesh Puja in Bangalore | Housewarming Pandit Booking',
    seoDescription:
      'Book Griha Pravesh Puja in Bangalore with North Hindi Pandit for vastu shanti, housewarming rituals, shubh muhurat guidance, and complete puja samagri.',
    benefits: [
      'Brings divine blessings, positivity, and spiritual harmony to your new home.',
      'Supports Vastu Shanti rituals before shifting or immediately after possession.',
      'Performed in clear Hindi with traditional North Indian vidhi.',
      'Available for apartments, villas, independent houses, and office spaces in Bangalore.',
    ],
    idealFor: [
      'New flat possession and first entry into the home',
      'Housewarming after renovation or interior completion',
      'Families moving to Bangalore and wanting authentic North Indian rituals',
      'Office openings, studio launches, and new commercial spaces',
    ],
    includes: [
      'Pandit ji guidance for muhurat and puja preparation',
      'Kalash puja, Ganesh puja, Navagraha prayers, and Vastu Shanti rituals',
      'Havan process with mantra chanting',
      'Puja samagri support based on the selected package',
    ],
    process: [
      'Share your location, preferred date, and house details on WhatsApp or call.',
      'Receive guidance on muhurat, setup, and required arrangements.',
      'Pandit ji arrives on time and performs the full housewarming vidhi.',
      'Family members are guided step by step for sankalp, havan, and blessings.',
    ],
    faqs: [
      {
        question: 'Do you provide Griha Pravesh Puja for flats and apartments in Bangalore?',
        answer:
          'Yes. We provide Griha Pravesh Puja for apartments, villas, rented homes, independent houses, and office spaces across Bangalore.',
      },
      {
        question: 'Can you help with same-day or urgent housewarming booking?',
        answer:
          'Yes, same-day and urgent booking may be possible depending on pandit availability and your location in Bangalore.',
      },
    ],
  },
  {
    slug: 'satyanarayan-puja-bangalore',
    title: 'Satyanarayan Puja in Bangalore',
    shortTitle: 'Satyanarayan Puja',
    image: '/images/satyanarayan-puja-all-puja.webp',
    tagline: 'A beloved Vishnu puja for family peace, prosperity, and fulfillment.',
    navLabel: 'Satyanarayan',
    heroTitle: 'Book Satyanarayan Puja in Bangalore for Family Peace and Blessings',
    heroDescription:
      'Arrange a complete Satyanarayan Katha and puja at home with an experienced Hindi-speaking pandit in Bangalore. Ideal for family occasions, birthdays, anniversaries, and spiritual thanksgiving.',
    seoTitle: 'Satyanarayan Puja in Bangalore | Satyanarayan Katha Pandit',
    seoDescription:
      'Book Satyanarayan Puja in Bangalore with North Hindi Pandit for complete Katha, Vishnu puja, prasad rituals, and authentic North Indian vidhi at home.',
    benefits: [
      'Performed for family well-being, gratitude, prosperity, and spiritual growth.',
      'Ideal for Purnima, housewarming, birthdays, anniversaries, and special occasions.',
      'Traditional Satyanarayan Katha explained clearly for the family.',
      'Convenient home booking across Bangalore with samagri support.',
    ],
    idealFor: [
      'Monthly Purnima Satyanarayan vrat and puja',
      'Housewarming and griha shanti ceremonies',
      'Business milestones and family thanksgiving occasions',
      'Birthday, anniversary, and naming celebration pujas',
    ],
    includes: [
      'Ganesh puja and sankalp before the main vidhi',
      'Full Satyanarayan Katha recitation and Vishnu pujan',
      'Aarti, prasad vidhi, and family participation guidance',
      'Support for puja samagri and preparation checklist',
    ],
    process: [
      'Choose your date and share your Bangalore location.',
      'Receive a simple preparation checklist for altar and prasad.',
      'Pandit ji performs the Katha, puja, and aarti with family involvement.',
      'Booking help remains available for follow-up rituals or future pujas.',
    ],
    faqs: [
      {
        question: 'Do you perform Satyanarayan Katha in Hindi?',
        answer:
          'Yes. The puja and Katha are performed in Hindi with clear guidance so the family can follow every step comfortably.',
      },
      {
        question: 'Is puja samagri available with the booking?',
        answer:
          'Yes. Based on the package selected, we can guide you with the list or arrange the samagri support as needed.',
      },
    ],
  },
  {
    slug: 'ganesh-puja-bangalore',
    title: 'Ganesh Puja in Bangalore',
    shortTitle: 'Ganesh Puja',
    image: '/images/ganesh-puja-all-puja.webp',
    tagline: 'Invoke Lord Ganesh before every new beginning with an auspicious puja.',
    navLabel: 'Ganesh Puja',
    heroTitle: 'Book Ganesh Puja in Bangalore for Auspicious New Beginnings',
    heroDescription:
      'Perform Ganesh Puja for home, office, business launch, education goals, or important family milestones with a trusted North Hindi Pandit in Bangalore.',
    seoTitle: 'Ganesh Puja in Bangalore | Ganpati Puja Pandit Booking',
    seoDescription:
      'Book Ganesh Puja in Bangalore with North Hindi Pandit for home, office, new business, vehicle, education, and auspicious start ceremonies.',
    benefits: [
      'Seeks the blessings of Vighnaharta before important beginnings.',
      'Suitable for home puja, office openings, and business inauguration.',
      'Peaceful and devotional vidhi performed with proper mantra chanting.',
      'Simple booking and family-friendly guidance in Bangalore.',
    ],
    idealFor: [
      'New business launch and office inauguration',
      'Vehicle delivery or first-time use blessing',
      'Education-related prayers before exams or admissions',
      'Ganesh Chaturthi and special devotional occasions',
    ],
    includes: [
      'Ganapati avahan, pujan, mantra chanting, and aarti',
      'Setup guidance for murti, flowers, and offerings',
      'Family participation support during sankalp and aarti',
      'Optional combination with Vastu or opening rituals',
    ],
    process: [
      'Send your preferred date, location, and purpose of puja.',
      'Receive booking confirmation and setup instructions.',
      'Pandit ji conducts the puja with devotion and proper vidhan.',
      'Finish with aarti, blessings, and prasad guidance.',
    ],
    faqs: [
      {
        question: 'Can Ganesh Puja be done for office or shop opening in Bangalore?',
        answer:
          'Yes. We provide Ganesh Puja for homes, offices, showrooms, shops, clinics, and commercial spaces throughout Bangalore.',
      },
      {
        question: 'Do you provide North Indian style Ganesh Puja?',
        answer:
          'Yes. The puja is performed with authentic North Indian traditions and Hindi guidance for the family.',
      },
    ],
  },
  {
    slug: 'maha-mrityunjaya-jaap-bangalore',
    title: 'Maha Mrityunjaya Jaap in Bangalore',
    shortTitle: 'Maha Mrityunjaya Jaap',
    image: '/images/hindi-pandit-all-puja.webp',
    tagline: 'A powerful Shiva mantra ritual for healing prayers, protection, and inner strength.',
    navLabel: 'Maha Mrityunjaya',
    heroTitle: 'Book Maha Mrityunjaya Jaap in Bangalore for Health, Protection, and Peace',
    heroDescription:
      'Arrange Maha Mrityunjaya Jaap and Shiva prayers at home in Bangalore for healing intentions, protection from negativity, and spiritual comfort during difficult times.',
    seoTitle: 'Maha Mrityunjaya Jaap in Bangalore | Shiva Jaap Pandit Booking',
    seoDescription:
      'Book Maha Mrityunjaya Jaap in Bangalore with North Hindi Pandit for Shiva mantra chanting, healing prayers, spiritual protection, and family peace at home.',
    benefits: [
      'Performed for spiritual strength, healing intentions, and peace of mind.',
      'Dedicated Shiva mantra chanting in a disciplined and devotional manner.',
      'Suitable for family well-being prayers and difficult life phases.',
      'Available in homes across Bangalore with guided participation.',
    ],
    idealFor: [
      'Health and recovery prayers for loved ones',
      'Protection and peace during stressful periods',
      'Shiva bhakti and spiritual strengthening rituals',
      'Family-led sankalp for positive energy and blessings',
    ],
    includes: [
      'Sankalp and Shiva invocation before mantra chanting',
      'Maha Mrityunjaya mantra jaap according to selected format',
      'Aarti and concluding blessings for the family',
      'Guidance for offerings such as bel patra, milk, and flowers',
    ],
    process: [
      'Share the purpose, location, and date of the jaap.',
      'Receive guidance for basic preparation and offerings.',
      'Pandit ji performs the jaap with focused mantra chanting.',
      'The ritual concludes with blessings and simple follow-up guidance.',
    ],
    faqs: [
      {
        question: 'Can Maha Mrityunjaya Jaap be performed at home in Bangalore?',
        answer:
          'Yes. We provide home booking across Bangalore for families who want sincere Shiva mantra chanting and guided participation.',
      },
      {
        question: 'Do you guide what items are needed for the jaap?',
        answer:
          'Yes. We share a simple checklist and can also guide you on common offerings used for Shiva puja and jaap.',
      },
    ],
  },
  {
    slug: 'bhoomi-puja-bangalore',
    title: 'Bhoomi Puja in Bangalore',
    shortTitle: 'Bhoomi Puja',
    image: '/images/hindi-pandit-all-puja.webp',
    tagline: 'Begin construction and land development with sacred blessings and Vedic rituals.',
    navLabel: 'Bhoomi Puja',
    heroTitle: 'Book Bhoomi Puja in Bangalore Before Construction or Site Work',
    heroDescription:
      'Perform Bhoomi Puja for residential plots, villas, commercial projects, and land development with an experienced Hindi-speaking pandit in Bangalore.',
    seoTitle: 'Bhoomi Puja in Bangalore | Land Puja Pandit Booking',
    seoDescription:
      'Book Bhoomi Puja in Bangalore with North Hindi Pandit for plot blessing, construction start rituals, Vastu prayers, and sacred land worship.',
    benefits: [
      'Seeks blessings before digging, construction, or land development.',
      'Ideal for residential plots, villas, apartments, and commercial sites.',
      'Traditional North Indian vidhi with clear guidance for family or builders.',
      'Helps start new projects with a sacred and positive foundation.',
    ],
    idealFor: [
      'Vacant plot puja before construction starts',
      'Villa foundation, apartment site, and bungalow projects',
      'Office, shop, and commercial construction work',
      'Land blessing before major renovation or extension',
    ],
    includes: [
      'Ganesh puja and Bhoomi Devi invocation',
      'Vastu-oriented prayers and sankalp',
      'Havan and site blessing rituals',
      'Support for ceremony timing and basic site setup',
    ],
    process: [
      'Share your site location in Bangalore and preferred date.',
      'Receive confirmation along with basic site setup guidance.',
      'Pandit ji performs the Bhoomi Puja with proper mantra chanting.',
      'The ritual concludes with blessings for safe and successful construction.',
    ],
    faqs: [
      {
        question: 'Do you provide Bhoomi Puja for construction sites in Bangalore?',
        answer:
          'Yes. We perform Bhoomi Puja for residential, commercial, and builder sites across Bangalore.',
      },
      {
        question: 'Can Bhoomi Puja be combined with Vastu-related rituals?',
        answer:
          'Yes. Depending on the requirement, we can guide you on suitable Vastu-related prayers and setup.',
      },
    ],
  },
  {
    slug: 'marriage-puja-bangalore',
    title: 'Marriage Puja in Bangalore',
    shortTitle: 'Marriage Puja',
    image: '/images/marriage-puja-pandit.webp',
    tagline: 'Traditional North Indian wedding rituals performed with dignity, warmth, and Vedic precision.',
    navLabel: 'Marriage Puja',
    heroTitle: 'Book North Indian Marriage Puja in Bangalore with Hindi-Speaking Pandit',
    heroDescription:
      'From engagement rituals to wedding day vidhi, book an experienced North Indian pandit in Bangalore for varmala, pheras, kanyadaan, havan, and complete shaadi ceremonies.',
    seoTitle: 'Marriage Puja in Bangalore | North Indian Wedding Pandit Booking',
    seoDescription:
      'Book Marriage Puja in Bangalore with North Hindi Pandit for North Indian wedding rituals, engagement puja, pheras, havan, and complete shaadi vidhi.',
    benefits: [
      'Traditional wedding ceremonies performed with proper Vedic sequence.',
      'Hindi-speaking pandit support for North Indian wedding customs.',
      'Suitable for engagement, roka, sagai, wedding, and griha pravesh after marriage.',
      'Calm and respectful guidance for families, couple, and event teams.',
    ],
    idealFor: [
      'North Indian wedding ceremonies in Bangalore',
      'Home weddings, banquet weddings, and temple weddings',
      'Engagement, sagai, roka, and marriage day rituals',
      'Destination-style family weddings within Bangalore city',
    ],
    includes: [
      'Wedding ritual planning and timing guidance',
      'Pheras, kanyadaan, mangalsutra, havan, and concluding blessings',
      'Clear instructions for bride, groom, and family members',
      'Support for engagement or pre-wedding puja arrangements',
    ],
    process: [
      'Share the wedding date, venue, and ceremony timing.',
      'Receive coordination support for ritual flow and required setup.',
      'Pandit ji performs the full marriage vidhi with graceful guidance.',
      'The ceremony is completed with blessings for the couple and both families.',
    ],
    faqs: [
      {
        question: 'Do you perform complete North Indian wedding rituals in Bangalore?',
        answer:
          'Yes. We provide complete North Indian marriage puja services in Bangalore, including engagement and wedding-day rituals.',
      },
      {
        question: 'Can you perform marriage puja at home or wedding hall?',
        answer:
          'Yes. We perform wedding rituals at homes, function halls, temples, and event venues across Bangalore.',
      },
    ],
  },
  {
    slug: 'rudrabhishek-puja-bangalore',
    title: 'Rudrabhishek Puja in Bangalore',
    shortTitle: 'Rudrabhishek Puja',
    image: '/images/rudrabhishek-puja-all-puja.webp',
    tagline: 'A sacred Shiva abhishek for peace, strength, positivity, and divine protection.',
    navLabel: 'Rudrabhishek',
    heroTitle: 'Book Rudrabhishek Puja in Bangalore with Trusted Shiv Bhakt Pandit',
    heroDescription:
      'Perform Rudrabhishek Puja at home in Bangalore for spiritual upliftment, family peace, obstacle removal, and devotional worship of Lord Shiva.',
    seoTitle: 'Rudrabhishek Puja in Bangalore | Shiva Abhishek Pandit Booking',
    seoDescription:
      'Book Rudrabhishek Puja in Bangalore with North Hindi Pandit for Shiva abhishek, mantra chanting, havan, and family blessings at home.',
    benefits: [
      'Dedicated Shiva puja performed with devotion and mantra discipline.',
      'Favored for peace, positivity, and spiritual cleansing.',
      'Suitable for Shravan month, Mondays, Mahashivratri, and special prayers.',
      'Comfortable home service across Bangalore with guidance in Hindi.',
    ],
    idealFor: [
      'Shravan month Shiva puja at home',
      'Mahashivratri and Monday special puja',
      'Family peace and negativity removal prayers',
      'Personal spiritual devotion and Shiva bhakti occasions',
    ],
    includes: [
      'Shiva sankalp, abhishek, mantra chanting, and aarti',
      'Guidance for milk, water, bel patra, flowers, and offerings',
      'Optional havan support depending on the package',
      'Simple participation support for family members',
    ],
    process: [
      'Send your Bangalore address and preferred puja date.',
      'Receive a preparation checklist and booking confirmation.',
      'Pandit ji performs Rudrabhishek with proper Shiva vidhi.',
      'The puja concludes with aarti, blessings, and prasad guidance.',
    ],
    faqs: [
      {
        question: 'Can Rudrabhishek Puja be performed at home in Bangalore?',
        answer:
          'Yes. We offer home Rudrabhishek Puja booking across Bangalore for families and devotees seeking Shiva blessings.',
      },
      {
        question: 'Is this puja available during Shravan month?',
        answer:
          'Yes. Rudrabhishek Puja is one of the most requested Shiva rituals during Shravan, and early booking is recommended.',
      },
    ],
  },
  {
    slug: 'shraadh-puja-bangalore',
    title: 'Shraadh Puja in Bangalore',
    shortTitle: 'Shraadh Puja',
    image: '/images/shraadh-puja-all-puja.webp',
    tagline: 'Respectful ancestral rituals performed with sincerity, tradition, and proper guidance.',
    navLabel: 'Shraadh Puja',
    heroTitle: 'Book Shraadh Puja in Bangalore with Experienced North Indian Pandit',
    heroDescription:
      'Arrange Shraadh, Pind Daan, and Pitru-related rituals in Bangalore with a respectful Hindi-speaking pandit who performs the ceremony with proper North Indian tradition.',
    seoTitle: 'Shraadh Puja in Bangalore | Pitru Puja Pandit Booking',
    seoDescription:
      'Book Shraadh Puja in Bangalore with North Hindi Pandit for Pitru rituals, tithi shraddh, ancestral prayers, and respectful North Indian vidhi at home.',
    benefits: [
      'Performed with sincerity and proper ancestral ritual discipline.',
      'Guided in a respectful manner for families observing tithi or Pitru Paksha.',
      'Suitable for home-based Shraadh ceremonies across Bangalore.',
      'Clear Hindi guidance for offerings, sankalp, and family participation.',
    ],
    idealFor: [
      'Annual tithi Shraddh at home',
      'Pitru Paksha ancestral rituals in Bangalore',
      'Pind Daan style home arrangements where applicable',
      'Families wanting North Indian vidhi and respectful guidance',
    ],
    includes: [
      'Pandit ji guidance for timing and ceremonial preparation',
      'Ancestral sankalp and Shraddh vidhi',
      'Support for required offerings and ritual sequence',
      'A calm, respectful, and family-sensitive puja experience',
    ],
    process: [
      'Share the tithi, date, and Bangalore location for booking.',
      'Receive a simple list of items and basic preparation guidance.',
      'Pandit ji performs the ancestral rituals with full sincerity.',
      'The family is guided carefully throughout the ceremony.',
    ],
    faqs: [
      {
        question: 'Do you perform Shraadh Puja at home in Bangalore?',
        answer:
          'Yes. We perform Shraadh Puja and related ancestral rituals at home across Bangalore with proper North Indian tradition.',
      },
      {
        question: 'Can you guide the family on the required preparations?',
        answer:
          'Yes. We guide families with the basic ritual preparations and list of items needed before the ceremony.',
      },
    ],
  },
];

export const pujaMap = new Map(pujas.map((puja) => [puja.slug, puja]));
