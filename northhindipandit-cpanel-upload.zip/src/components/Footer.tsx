import Link from 'next/link';
import { pujas } from '@/data/pujas';

export const Footer = () => {
  return (
    <footer className="py-20 bg-paper border-t border-ink/5">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
        <div className="flex flex-col">
          <span className="font-serif text-3xl font-bold tracking-tight text-ink mb-4">North Hindi Pandit</span>
          <p className="text-sm text-ink/60 leading-relaxed max-w-sm">
            Customer-friendly puja booking pages for Bangalore families seeking trusted North Indian rituals, clear guidance, and fast contact support.
          </p>
        </div>

        <div className="flex flex-col gap-4">
          <h4 className="text-xs uppercase tracking-[0.2em] font-bold text-saffron mb-2">Popular Puja Pages</h4>
          {pujas.slice(0, 4).map((puja) => (
            <Link key={puja.slug} href={`/services/${puja.slug}/`} className="text-sm hover:text-saffron transition-colors">
              {puja.shortTitle}
            </Link>
          ))}
        </div>

        <div className="flex flex-col gap-4">
          <h4 className="text-xs uppercase tracking-[0.2em] font-bold text-saffron mb-2">Contact Us</h4>
          <p className="text-sm text-ink/60">Serving major Bangalore locations for home and family pujas</p>
          <a href="tel:6206471543" className="text-sm font-bold">6206471543</a>
          <a href="mailto:contact@northhindipandit.com" className="text-sm hover:text-saffron transition-colors">contact@northhindipandit.com</a>
          <p className="text-xs uppercase tracking-[0.2em] text-ink/40">Pandit Nilesh Kumar Pandey</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-ink/5 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-[10px] uppercase tracking-widest text-ink/40">
          &copy; 2026 North Hindi Pandit. All rights reserved.
        </p>
        <div className="flex gap-6">
          <span className="text-[10px] uppercase tracking-widest text-ink/40">Bangalore Puja Booking</span>
          <span className="text-[10px] uppercase tracking-widest text-ink/40">North Indian Ritual Services</span>
        </div>
      </div>
    </footer>
  );
};
